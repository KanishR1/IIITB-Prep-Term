from scanner import *
import sys as s

def main():
    print("File name containing initial population :",s.argv[1])
    print("Number of generations to simulate :",s.argv[2])

main()